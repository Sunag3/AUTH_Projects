from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from datetime import datetime, timedelta
from dateutil import tz, parser
from tutorial.auth_helper import get_sign_in_flow, get_token_from_code
from django.contrib.auth.decorators import login_required


def home(request):
    context = initialize_context(request)
    return render(request, 'tutorial/home.html', context)


def sunag(request):
    context = initialize_context(request)
    return render(request,'tutorial/sj.html',context)


def initialize_context(request):
    context = {}

    # Check for any errors in the session
    error = request.session.pop('flash_error', None)

    if error != None:
        context['errors'] = []
        context['errors'].append(error)
        print('here')

    # Check for user in the session
    context['user'] = request.session.get('user', {'is_authenticated': False})

    return context


def sign_in(request):
    # Get the sign-in flow
    flow = get_sign_in_flow()
    # Save the expected flow so we can use it in the callback
    request.session['auth_flow'] = flow
    # Redirect to the Azure sign-in page
    return HttpResponseRedirect(flow['auth_uri'])


def callback(request):
    # Make the token request
    result = get_token_from_code(request)
    print('Auth')
    # Temporary! Save the response in an error so it's displayed
    request.session['flash_error'] = {
        'message': 'Token retrieved', 'debug': format(result)}
    return HttpResponseRedirect(reverse('sunag'))
